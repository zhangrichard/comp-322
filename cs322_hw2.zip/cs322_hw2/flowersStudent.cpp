#include "flowers.h"

unsigned int spitEulerSquare(unsigned int index) {
    // TODO : add code here
}

Fraction getApproximation(ContinuedFraction &fr, unsigned int n){
    // TODO : add code here
}


double getAngle(ContinuedFraction &theta, int k) {
    // TODO : add code here
}

Seed getSeed(ContinuedFraction &theta, int k) {
    // TODO : add code here
}

void pushSeed(std::list<Seed> &flower, ContinuedFraction &theta) {
    // TODO : add code here
}

int spitNextMagicBox(MagicBox &box) {
    // TODO : add code here
}

ContinuedFraction getCFUsingMB(ContinuedFraction &f, int a, int b, int length) {
    // TODO : add code here
}
